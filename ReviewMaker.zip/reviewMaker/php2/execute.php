<?php
$python_script = "../python/cameraDraw.py";
$output = array();

if (isset($_POST['execute'])) {
  // Execute the Python script and capture output
  exec("python $python_script 2>&1", $output);
}

if (isset($_POST['terminate'])) {
  // Terminate the Python script
  exec("pkill -f cameraDraw.py");
}

echo implode("\n", $output);
?>
