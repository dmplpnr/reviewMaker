<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// Database credentials
$host = "localhost";
$user = "root";
$password = "";
$database = "hci";

// Open a connection to the database
$conn = mysqli_connect($host, $user, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Read the CSV file into an array
$data = array();
if (($handle = fopen("data.csv", "r")) !== FALSE) {
    while (($row = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $data[] = $row;
    }
    fclose($handle);
}

// Insert the data into the database
foreach ($data as $row) {
    $question = mysqli_real_escape_string($conn, $row[0]);
    $answer = mysqli_real_escape_string($conn, $row[1]);
    $sql = "INSERT INTO db_reviewerteacher (std_Question, std_Answer) VALUES ('$question', '$answer')";
    if (mysqli_query($conn, $sql)) {
      

// Truncate the content of the CSV file
file_put_contents('data.csv', '', LOCK_EX);
    } else {
        echo "Error inserting record: " . mysqli_error($conn) . "\n";
    }
}
echo "<script>
alert('Question and Answer Saved');
window.setTimeout(function() {
    window.history.back();
}, 300); // Redirect back after 3 seconds
</script>";

// Close the database connection
mysqli_close($conn);
}
?>s