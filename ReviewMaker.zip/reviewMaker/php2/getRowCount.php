<?php
// Database connection settings
$host = "localhost";
$user = "root";
$password = "";
$database = "hci";
$table = "db_reviewerteacher";

// Connect to database
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query your database to retrieve the count of rows in a column
$query = "SELECT COUNT(std_Number) AS questionRow FROM $table";
$result = $conn->query($query);
$rowscount = $result->fetch_assoc();

// Close database connection
mysqli_close($conn);

// Return the result as a JSON object
echo json_encode($rowscount);
?>
