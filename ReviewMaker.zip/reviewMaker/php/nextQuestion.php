<?php
// Database connection settings
$host = "localhost";
$user = "root";
$password = "";
$database = "hci";
$table = "db_reviewerstudent";

// Connect to database
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


// Generate random number for selecting a random question from the database
$sql_count = "SELECT COUNT(*) FROM $table";
$result_count = mysqli_query($conn, $sql_count);
$count = mysqli_fetch_array($result_count)[0];
$random_id = rand(1, $count);

// Retrieve a random question and answer from the database
$sql_question = "SELECT std_Question, std_Answer FROM $table WHERE std_Number = $random_id";
$result_question = mysqli_query($conn, $sql_question);
$row = mysqli_fetch_assoc($result_question);

// query your database to retrieve the count of rows in a column
$query = "SELECT COUNT(std_Number) AS questionCount FROM db_reviewerstudent";
$result = $conn->query($query);
$rowscount = $result->fetch_assoc();


// Close database connection
mysqli_close($conn);

// Return the result as a JSON object
echo json_encode($row);

?>
