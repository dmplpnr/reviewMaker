<?php
$file = fopen("data.csv", "a");
fwrite($file, $_POST["data"]);
fclose($file);
echo "Data saved to file.";
?>