<?php
$servername = "localhost"; // Replace with your database servername
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$database = "hci"; // Replace with your database name

// Create a connection
$con = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>