<?php
// Retrieve form data
$username = $_POST['username'];
$password = $_POST['password'];
$accountType = $_POST['account-type'];

// Database connection parameters
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$database = "hci";

// Create database connection
$conn = new mysqli($servername, $dbUsername, $dbPassword, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize table and redirect URL variables
$table = "";
$redirectUrl = "";

// Determine table and redirect URL based on account type
if ($accountType === "Student") {
    $table = "std_accounts";
    $redirectUrl = "/student-index.html";
    $usernameField = "std_username";
    $passwordField = "std_password";
} elseif ($accountType === "Teacher") {
    $table = "tch_accounts";
    $redirectUrl = "/teacher-index.html";
    $usernameField = "tch_username";
    $passwordField = "tch_password";
} elseif ($accountType === "Admin") {
    $table = "ad_accounts";
    $redirectUrl = "/admin.html";
    $usernameField = "ad_username";
    $passwordField = "ad_password";
}

// Perform the query to check if username and password exist in the selected table
$sql = "SELECT * FROM $table WHERE $usernameField = '$username' AND $passwordField = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Login successful, display success notification and redirect to the appropriate page
    echo "<script>
        alert('User login successful!');
        window.setTimeout(function() {
            window.location.href = '$redirectUrl';
        }, 300); // Redirect after 3 seconds
    </script>";
} else {
    // Invalid username or password
    echo "<script>
        alert('Invalid username or password');
        window.setTimeout(function() {
            window.history.back();
        }, 300); // Redirect back after 3 seconds
    </script>";
}

// Close the database connection
$conn->close();
?>
