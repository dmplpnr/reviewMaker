<?php
// Retrieve form data
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$accountType = $_POST['account-type'];

// Database connection parameters
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$database = "hci";

// Create database connection
$conn = new mysqli($servername, $dbUsername, $dbPassword, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Determine the table name and column names based on the account type
$table = "";
$column_username = "";
$column_password = "";
$column_email = "";

if ($accountType === "option2") {
    $table = "std_accounts";
    $column_username = "std_username";
    $column_password = "std_password";
    $column_email = "std_email";
} elseif ($accountType === "option3") {
    $table = "tch_accounts";
    $column_username = "tch_username";
    $column_password = "tch_password";
    $column_email = "tch_email";
} else {
    echo "Invalid account type";
    exit;
}

// Construct the SQL query
$sql = "INSERT INTO `$table` (`$column_username`, `$column_password`, `$column_email`) VALUES ('$username', '$password', '$email')";

if ($conn->query($sql) === TRUE) {
    echo '<script>alert("User Signup Successful!");</script>';
    echo '<script>window.location.href = "/login.html";</script>';
} else {
    echo '<script>alert("User signup failed: ' . $conn->error . '");</script>';
}


// Close the database connection
$conn->close();
?>
