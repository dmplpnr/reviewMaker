-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2023 at 05:19 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hci`
--

-- --------------------------------------------------------

--
-- Table structure for table `ad_accounts`
--

CREATE TABLE `ad_accounts` (
  `ad_num` int(11) NOT NULL,
  `ad_username` varchar(125) NOT NULL,
  `ad_email` varchar(125) NOT NULL,
  `ad_password` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ad_accounts`
--

INSERT INTO `ad_accounts` (`ad_num`, `ad_username`, `ad_email`, `ad_password`) VALUES
(1, 'admin', 'admin@tip', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `db_reviewerstudent`
--

CREATE TABLE `db_reviewerstudent` (
  `std_Number` int(150) NOT NULL,
  `std_Question` varchar(150) NOT NULL,
  `std_Answer` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `db_reviewerstudent`
--

INSERT INTO `db_reviewerstudent` (`std_Number`, `std_Question`, `std_Answer`) VALUES
(1, 'This is the What is the capital?', 'what.'),
(2, 'What is the capital of Philippines?', 'Manila.'),
(3, 'What is the capital of Italy?', 'Italy.');

-- --------------------------------------------------------

--
-- Table structure for table `db_reviewerteacher`
--

CREATE TABLE `db_reviewerteacher` (
  `std_Number` int(150) NOT NULL,
  `std_Question` varchar(150) NOT NULL,
  `std_Answer` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `db_reviewerteacher`
--

INSERT INTO `db_reviewerteacher` (`std_Number`, `std_Question`, `std_Answer`) VALUES
(1, 'teacher capital of PH', 'manila'),
(2, 'What is the capital of Italy?', 'Italy.');

-- --------------------------------------------------------

--
-- Table structure for table `std_accounts`
--

CREATE TABLE `std_accounts` (
  `std_num` int(125) NOT NULL,
  `std_username` varchar(125) NOT NULL,
  `std_email` varchar(125) NOT NULL,
  `std_password` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `std_accounts`
--

INSERT INTO `std_accounts` (`std_num`, `std_username`, `std_email`, `std_password`) VALUES
(1, 'student', 'student@tip', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `tch_accounts`
--

CREATE TABLE `tch_accounts` (
  `tch_num` int(125) NOT NULL,
  `tch_username` varchar(125) NOT NULL,
  `tch_email` varchar(125) NOT NULL,
  `tch_password` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tch_accounts`
--

INSERT INTO `tch_accounts` (`tch_num`, `tch_username`, `tch_email`, `tch_password`) VALUES
(1, 'teacher', 'teacher@tip', 'teacher');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ad_accounts`
--
ALTER TABLE `ad_accounts`
  ADD PRIMARY KEY (`ad_num`);

--
-- Indexes for table `db_reviewerstudent`
--
ALTER TABLE `db_reviewerstudent`
  ADD PRIMARY KEY (`std_Number`);

--
-- Indexes for table `db_reviewerteacher`
--
ALTER TABLE `db_reviewerteacher`
  ADD PRIMARY KEY (`std_Number`);

--
-- Indexes for table `std_accounts`
--
ALTER TABLE `std_accounts`
  ADD PRIMARY KEY (`std_num`);

--
-- Indexes for table `tch_accounts`
--
ALTER TABLE `tch_accounts`
  ADD PRIMARY KEY (`tch_num`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ad_accounts`
--
ALTER TABLE `ad_accounts`
  MODIFY `ad_num` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_reviewerstudent`
--
ALTER TABLE `db_reviewerstudent`
  MODIFY `std_Number` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `db_reviewerteacher`
--
ALTER TABLE `db_reviewerteacher`
  MODIFY `std_Number` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `std_accounts`
--
ALTER TABLE `std_accounts`
  MODIFY `std_num` int(125) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tch_accounts`
--
ALTER TABLE `tch_accounts`
  MODIFY `tch_num` int(125) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
